<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <style>
        body {
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
            background-color: #3498db; /* Warna latar belakang */
        }

        .register-container {
            background-color: #ecf0f1; /* Warna latar form */
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            padding: 20px;
            width: 300px;
            text-align: center;
        }

        .register-form {
            display: flex;
            flex-direction: column;
        }

        .register-form h1 {
            color: #2c3e50; /* Warna teks judul */
        }

        .input-group {
            margin-bottom: 15px;
        }

        label {
            display: block;
            margin-bottom: 5px;
            color: #34495e; /* Warna teks label */
        }

        input {
            padding: 8px;
            width: 100%;
            box-sizing: border-box;
            border: 1px solid #bdc3c7; /* Warna border input */
            border-radius: 5px;
        }

        button {
            background-color: #2ecc71; /* Warna tombol */
            color: #fff; /* Warna teks tombol */
            padding: 10px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }

        button:hover {
            background-color: #27ae60; /* Warna tombol saat dihover */
        }
    </style>
    <title>Register Form</title>
</head>
<body>
    <div class="register-container">
        <form class="register-form" action="registerasiAksi" method="post">
            @csrf
            <h1>Register</h1>
            <div class="input-group">
                <label for="username">Username</label>
                <input type="text" id="username" name="username" required>
            </div>
            <div class="input-group">
                <label for="password">Password</label>
                <input type="password" id="password" name="password" required>
            </div>
            <div class="input-group">
                <label for="email">Email</label>
                <input type="email" id="email" name="email" required>
            </div>
            <div class="input-group">
                <label for="fullname">Full Name</label>
                <input type="text" id="fullname" name="fullname" required>
            </div>
            <div class="input-group">
                <label for="address">Address</label>
                <input type="text" id="address" name="address" required>
            </div>
            <button type="submit">Register</button>
        </form>
    </div>
</body>
</html>

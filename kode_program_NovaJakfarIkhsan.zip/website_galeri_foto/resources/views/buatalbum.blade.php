<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <style>
        body {
            margin: 0;
            padding: 0;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }

        nav {
            background-color: #2c3e50;
            padding: 10px;
            text-align: center;
            
        }

        nav a {
            color: #ecf0f1;
            text-decoration: none;
            padding: 10px;
            margin: 0 10px;
        }

        .container {
            flex: 1;
            display: flex;
            justify-content: center;
            align-items: center;
            flex-direction: column;
        }

        h1 {
            color: #2c3e50;
        }

        .form-container {
            margin-top: 20px;
            width: 50%;
            max-width: 400px;
        }

        label {
            display: block;
            margin-bottom: 8px;
            color: #34495e;
        }

        input, textarea {
            width: 100%;
            padding: 10px;
            margin-bottom: 16px;
            border: 1px solid #ccc;
            border-radius: 4px;
            box-sizing: border-box;
        }

        button {
            background-color: #3498db;
            color: #ecf0f1;
            padding: 15px 30px;
            font-size: 16px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }
    </style>
    <title>Buat Album</title>
</head>
<body>

    <nav>
        <a href="/home">Home</a>
    </nav>

    <div class="container" id="create-album">
        <h1>Buat Album Baru</h1>
        <form action="buatalbum" method="post">
            @csrf
        <div class="form-container">
            <label for="album-title">Judul Album:</label>
            <input type="text" id="album-title" name="judul" required>

            <label for="album-description">Deskripsi Album:</label>
            <textarea id="album-description" name="deskripsi" rows="4" required></textarea>

            <button>Buat Album</button>
        </div>
        </form>
    </div>



</body>
</html>

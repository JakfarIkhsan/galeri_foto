<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <style>
        body {
            margin: 0;
            padding: 0;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }

        nav {
            background-color: #2c3e50;
            padding: 10px;
            text-align: center;
        }

        nav a {
            color: #ecf0f1;
            text-decoration: none;
            padding: 10px;
            margin: 0 10px;
        }

        .container {
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
            flex-direction: column;
        }

        h1 {
            color: #2c3e50;
        }

        p {
            color: #34495e;
            max-width: 600px;
            text-align: center;
            line-height: 1.6;
            margin-top: 20px;
        }

        /* Style for Upload Page */
        .upload-container {
            max-width: 600px;
            margin-top: 20px;
        }

        .upload-form {
            display: flex;
            flex-direction: column;
            align-items: center;
        }

        .form-group {
            margin-bottom: 20px;
            width: 100%;
        }

        label {
            display: block;
            margin-bottom: 8px;
        }

        input, textarea, select {
            width: 100%;
            padding: 10px;
            margin-bottom: 10px;
            box-sizing: border-box;
        }

        button {
            background-color: #3498db;
            color: #fff;
            padding: 10px;
            border: none;
            cursor: pointer;
        }
    </style>
    <title>Upload Page</title>
</head>
<body>

    <nav>
    <a href="{{asset('/home')}}">Home</a>
        <a href="/album">Album</a>
    </nav>

    <!-- Upload Page Content -->
    <center>
    <div class="container upload-container">
        <h1>Unggah Foto</h1>
        <form class="upload-form" action="/upload" method="post" enctype="multipart/form-data">
            @csrf
            <div class="form-group">
                <label for="title">Judul Foto:</label>
                <input type="text" id="title" name="title" required>
            </div>
            <div class="form-group">
                <label for="description">Deskripsi Foto:</label>
                <textarea id="description" name="description" rows="4" required></textarea>
            </div>
            <div class="form-group">
                <label for="image">Pilih File Foto:</label>
                <input type="file" id="image" name="image" accept="image/*" required>
            </div>
            <div class="form-group">
                <label for="album">Pilih Album:</label>
                <select id="album" name="album" required>
            @foreach ($data as $alb)
            <option value="{{ $alb->AlbumID }}">{{ $alb->NamaAlbum }}</option>

            @endforeach
                </select>
            </div>
            <button type="submit">Unggah</button>
        </form>
    </div>
    </center>

</body>
</html>

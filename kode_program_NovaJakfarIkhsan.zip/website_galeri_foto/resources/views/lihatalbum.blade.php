<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <style>
        body {
            margin: 0;
            padding: 0;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }

        nav {
            background-color: #2c3e50;
            padding: 10px;
            text-align: center;
        }

        nav a {
            color: #ecf0f1;
            text-decoration: none;
            padding: 10px;
            margin: 0 10px;
        }

        .container {
            display: flex;
            justify-content: center;
            align-items: center;
            flex-direction: column;
        }

        h1 {
            color: #2c3e50;
        }

        p {
            color: #34495e;
            max-width: 600px;
            text-align: center;
            line-height: 1.6;
            margin-top: 20px;
        }

        /* Style for Album Page */
        /* .album-container {
            display: flex;
            justify-content: center;
            overflow-x: auto;
            margin-top: 20px;
        } */

        .album-group {
            display: flex; /* Display flex untuk menggabungkan elemen-elemen dalam satu baris */
            justify-content: center;
        }

        .album-item {
            padding: 20px;
            background-color: white;
            text-align: center;
            border: 2px solid #111;
            margin: 10px 4px;
            border-radius: 10px;
            box-shadow: 0 0 8px #222;
        }
        .album-item:hover{
            transform: scale(1.1);
            transition: 0.3s;
        }
        a{
            color: #222;
            text-decoration: none;
        }
        .wadah{
            display: grid;
            gap: 10px;
            grid-template-columns: auto auto auto;
            justify-content: center;
        }
    </style>
    <title>Album Page</title>
</head>
<body>

    <nav>
        <a href="/home">Home</a>
        <a href="/album">Album</a>
    </nav>

    <div class="container" id="home">
        <h1>Selamat Datang Di Galeri Foto</h1>
        <p>
            Tempat di mana kreativitas dan keindahan bersatu. Kami mengundang Anda untuk menjelajahi dunia inspiratif kami, penuh dengan kisah, gambar, dan momen berharga.
        </p>
    </div>

    <!-- Album Page Content -->
    <div class="container album-container">
        <h1>Selamat Datang, Ini adalah Album Kamu</h1>
    <div class="wadah">
        @foreach($data as $album)
            <a href="/lihatfoto/{{$album->AlbumID}}">
                 <div class="album-item">
                    {{$album->NamaAlbum}}
                 </div>
            </a>
         @endforeach
    </div>
</div>

</body>
</html>

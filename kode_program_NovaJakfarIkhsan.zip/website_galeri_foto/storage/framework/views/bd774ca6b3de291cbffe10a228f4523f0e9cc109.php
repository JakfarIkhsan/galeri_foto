<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <style>
        body {
            margin: 0;
            padding: 0;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }

        nav {
            background-color: #2c3e50;
            padding: 10px;
            text-align: center;
        }

        nav a {
            color: #ecf0f1;
            text-decoration: none;
            padding: 10px;
            margin: 0 10px;
        }
        .cont {
    display: flex;
    flex-direction: column;
    align-items: center;
    margin-top: 20px;
    padding: 20px;
    background-color: #fff;
    border-radius: 8px;
    box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
}

img {
    width: 100%;
    max-width: 600px;
    border-radius: 8px;
    margin-bottom: 20px;
}

.kom {
    display: flex;
    justify-content: center;
    align-items: center;
    margin-bottom: 20px;
}

.kom a {
    color: #34495e;
    text-decoration: none;
    margin-right: 5px;
}

.kom i {
    font-size: 20px;
}

.desk {
    text-align: center;
    margin-bottom: 20px;
}

.desk p {
    margin: 5px 0;
}

.kom-left {
    display: flex;
    align-items: center;
    margin-bottom: 10px;
}

.user-com {
    margin-right: 5px;
}

.tgl-kom {
    color: #95a5a6;
    margin-bottom: 10px;
}

.create-kom {
    text-align: center;
}

.create-kom input[type="text"] {
    padding: 10px;
    width: 80%;
    margin-right: 5px;
    border-radius: 8px;
    border: 1px solid #ccc;
}

.create-kom button {
    padding: 10px 20px;
    background-color: #2c3e50;
    color: #fff;
    border: none;
    border-radius: 8px;
    cursor: pointer;
}
 
.create-kom button:hover {
    background-color: #34495e;
}

    </style>
</head>
<body>
    
    <nav>
        <a href="<?php echo e(asset('/home')); ?>">Home</a>
        <a href="/unggahfoto">Unggah Foto</a>
        <a href="/album">Album</a>
        <a href="#"><?php echo e(session('user')->Username); ?></a>
    </nav>
    <div class="cont">
    <img src="<?php echo e(Storage::url($foto->LokasiFile)); ?>" alt="">
    <div class="kom">
    <?php if($cek = $like->where('UserID', session('user')->UserID)->where('FotoID', $foto->FotoID)->first()): ?>
                        <a href="/berilike/<?php echo e($foto->FotoID); ?>">
                            <i class="fa-solid fa-thumbs-up" style="font-size: 20px"></i>
                        </a>
                        <?php echo e($like->where('FotoID', $foto->FotoID)->count()); ?>

                    <?php else: ?>
                        <a href="/berilike/<?php echo e($foto->FotoID); ?>">
                            <i class="fa-regular fa-thumbs-up" style="font-size: 20px"></i>
                        </a>
                        <?php echo e($like->where('FotoID', $foto->FotoID)->count()); ?>

                    <?php endif; ?>
    </div>
    <div class="desk">
    <p>Judul Foto:<?php echo e($foto->JudulFoto); ?></p>
    <p>Deskripsi Foto:<?php echo e($foto->DeskripsiFoto); ?></p>
    <p>Di Upload: <?php echo e($user->NamaLengkap); ?></p>
    </div>
    </div>

    <hr>

    <div class="kom">
    <?php $__currentLoopData = $komen; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kom): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="kom-left">
                        <div class="user-com"><i class="fa-solid fa-circle-user"></i>
                            <?php if($namanya = $user2->where('UserID', $kom->UserID)->first()): ?>
                                <?php echo e($namanya->NamaLengkap); ?>

                            <?php endif; ?>
                        </div>
                        <div class="isi-com"><?php echo e($kom->IsiKomentar); ?></div>
                    </div>
                    <div class="tgl-kom">
                        <?php echo e($kom->TanggalKomentar); ?>

                    </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    <div class="create-kom">
            <form action="/berikomen/<?php echo e($foto->FotoID); ?>" method="post">
                <?php echo csrf_field(); ?>
                <input type="text" name="isi" placeholder="Masukkan komentar kamu..." required class="isi-komen">
                <button><i class="fa-solid fa-paper-plane"></i></button>
            </form>
        </div>
    </div>
    <script src="https://kit.fontawesome.com/29c53c391a.js" crossorigin="anonymous"></script>
</body>
</html><?php /**PATH C:\Users\asus\website_galeri_foto\resources\views/lihatfoto.blade.php ENDPATH**/ ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <style>
        body {
            margin: 0;
            padding: 0;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }

        nav {
            background-color: #2c3e50;
            padding: 10px;
            text-align: center;
        }

        nav a {
            color: #ecf0f1;
            text-decoration: none;
            padding: 10px;
            margin: 0 10px;
        }

        .container {
            display: flex;
            justify-content: center;
            align-items: center;
            flex-direction: column;
        }

        h1 {
            color: #2c3e50;
        }

        p {
            color: #34495e;
            max-width: 600px;
            text-align: center;
            line-height: 1.6;
            margin-top: 20px;
        }

        /* Style for Album Page */
        /* .album-container {
            display: flex;
            justify-content: center;
            overflow-x: auto;
            margin-top: 20px;
        } */

        .album-group {
            display: flex; /* Display flex untuk menggabungkan elemen-elemen dalam satu baris */
            justify-content: center;
        }

        .album-item {
display: flex;
flex-direction: row;
        }

        .album-item img {
            width: 400px;
            height: auto;
            
        }
    </style>
    <title>Album Page</title>
</head>
<body>

    <nav>
        <a href="#home">Home</a>
        <a href="/album">Album</a>
    </nav>

    <div class="container" id="home">
        <h1>Selamat Datang Di Galeri Foto</h1>
        <p>
            Tempat di mana kreativitas dan keindahan bersatu. Kami mengundang Anda untuk menjelajahi dunia inspiratif kami, penuh dengan kisah, gambar, dan momen berharga.
        </p>
    </div>

    <!-- Album Page Content -->
    <div class="container album-container">
        <h1>Selamat Datang, Ini adalah Album Kamu</h1>
            <div class="album-item">
                <img src="image/pto garuda.png" alt="Photo 1">
                <img src="image/hellokity.jpg" alt="Photo 2">
                <img src="image/spons.webp" alt="Photo 3">
            </div>
    </div>

</body>
</html>
<?php /**PATH C:\Users\asus\website_galeri_foto\resources\views/lihatalbum.blade.php ENDPATH**/ ?>
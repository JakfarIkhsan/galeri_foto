<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <style>
        body {
            margin: 0;
            padding: 0;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }

        nav {
            background-color: #2c3e50;
            padding: 10px;
            text-align: center;
        }

        nav a {
            color: #ecf0f1;
            text-decoration: none;
            padding: 10px;
            margin: 0 10px;
        }

        .container {
            display: flex;
            justify-content: center;
            align-items: center;
            /* min-height: 100vh; */
            margin-top: 5%;
            flex-direction: column;
        }

        h1 {
            color: #2c3e50;
        }

        p {
            color: #34495e;
            max-width: 600px;
            text-align: center;
            line-height: 1.6;
            margin-top: 20px;
        }
        .contain{
            display: grid;
            grid-template-columns: auto auto auto auto;
            padding: 10px 100px;
        }
        .contain .gmbr img{
            border-radius: 10px;
            border: 2px solid #222;
            box-shadow: 0 0 8px #333;
            max-width: 300px;
        }

    </style>
    <title>Home Page</title>
</head>
<body>

    <nav>
    <a href="<?php echo e(asset('/home')); ?>">Home</a>
        <a href="/unggahfoto">Unggah Foto</a>
        <a href="/album">Album</a>
    </nav>

    <div class="container" id="home">
        <h1>Selamat Datang Di Galeri Foto</h1>
        <p>
        tempat di mana kreativitas dan keindahan bersatu. Kami mengundang Anda untuk menjelajahi dunia inspiratif kami, penuh dengan kisah, gambar, dan momen berharga.
        </p>
    </div>

    <div class="contain">
        <?php $__currentLoopData = $foto; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ft): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <a href="/lihatfoto2/<?php echo e($ft->FotoID); ?>">
        <div class="gmbr">
            <img src="<?php echo e(Storage::url($ft->LokasiFile)); ?>" alt="...">
        </div>
        </a>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    </div>

</body>
</html>
<?php /**PATH C:\Users\asus\website_galeri_foto\resources\views/home.blade.php ENDPATH**/ ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <style>
        body {
            margin: 0;
            padding: 0;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }

        nav {
            background-color: #2c3e50;
            padding: 10px;
            text-align: center;
            
        }

        nav a {
            color: #ecf0f1;
            text-decoration: none;
            padding: 10px;
            margin: 0 10px;
        }

        .container {
            flex: 1;
            display: flex;
            justify-content: center;
            align-items: center;
            flex-direction: column;
            margin-top: 100px;
        }

        h1 {
            color: #2c3e50;
        }

        .button-container {
            margin-top: 20px;
        }

        button {
            background-color: #3498db;
            color: #ecf0f1;
            padding: 15px 30px;
            font-size: 16px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }


    </style>
    <title>View Album</title>
</head>
<body>

<nav>
        <a href="/home">Home</a>
        <!-- <a href="/album">Album</a> -->
    </nav>


    <div class="container" id="view-album">
        <h1>View Album</h1>
        <div class="button-container">
            <a href="/buatalbum"><button>Buat Album</button></a>
            <a href="/lihatalbum"><button>lihat album</button></a>
        </div>
    </div>



</body>
</html>
<?php /**PATH C:\Users\asus\website_galeri_foto\resources\views/album.blade.php ENDPATH**/ ?>
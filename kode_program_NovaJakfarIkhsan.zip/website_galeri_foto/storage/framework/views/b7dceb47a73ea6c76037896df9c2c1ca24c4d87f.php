<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <style>
        body {
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
            background-color: #3498db; /* Warna latar belakang */
            font-family: 'Verdana';
        }

        .login-container {
            background-color: #ecf0f1; /* Warna latar form */
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            padding: 20px;
            width: 300px;
            text-align: center;
        }

        .login-form {
            display: flex;
            flex-direction: column;
        }

        .login-form h1 {
            color: #2c3e50; /* Warna teks judul */
        }

        .input-group {
            margin-bottom: 15px;
        }

        label {
            display: block;
            margin-bottom: 5px;
            color: #34495e; /* Warna teks label */
        }

        input {
            padding: 8px;
            width: 100%;
            box-sizing: border-box;
            border: 1px solid #bdc3c7; /* Warna border input */
            border-radius: 5px;
        }

        button {
            background-color: #2ecc71; /* Warna tombol */
            color: #fff; /* Warna teks tombol */
            padding: 10px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }

        button:hover {
            background-color: #27ae60; /* Warna tombol saat dihover */
        }
    </style>
    <title>Login Form</title>
</head>
<body>
    <div class="login-container">
        <form class="login-form" action="LoginAksi" method="post">
            <?php echo csrf_field(); ?>
            <h1>Login</h1>

            <p style="color: red;"><?php echo session('pesan'); ?></p>
            
            <div class="input-group">
                <label for="username">Username</label>
                <input type="text" id="username" name="username" required>
            </div>
            <div class="input-group">
                <label for="password">Password</label>
                <input type="password" id="password" name="password" required>
                <p>belum punya akun?, <a href="register">daftar</a> sekarang</p>
            </div>
            <button type="submit">Login</button>
        </form>
    </div>
</body>
</html>
<?php /**PATH C:\Users\asus\website_galeri_foto\resources\views/login.blade.php ENDPATH**/ ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <style>
        body {
            margin: 0;
            padding: 0;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #f0f0f0;
        }

        nav {
            background-color: #2c3e50;
            padding: 10px;
            text-align: center;
        }

        nav a {
            color: #ecf0f1;
            text-decoration: none;
            padding: 10px;
            margin: 0 10px;
        }

        .container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 20px;
        }

        h1 {
            color: #2c3e50;
            text-align: center;
            margin-bottom: 20px;
        }

        .gallery {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 20px;
        }

        .image-item {
            position: relative;
            overflow: hidden;
            border-radius: 10px;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.1);
            cursor: pointer;
        }

        .image-item img {
            width: 100%;
            height: auto;
            transition: transform 0.3s ease;
        }

        .image-item:hover img {
            transform: scale(1.05);
        }

        .image-overlay {
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0, 0, 0, 0.5);
            color: #fff;
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
            opacity: 0;
            transition: opacity 0.3s ease;
        }

        .image-overlay:hover {
            opacity: 1;
        }

        .image-overlay h3 {
            margin-bottom: 10px;
        }

        .image-overlay p {
            font-size: 14px;
            line-height: 1.6;
            margin-bottom: 20px;
        }
    </style>
    <title>Lihat Foto</title>
</head>
<body>

    <nav>
    <a href="<?php echo e(asset('/home')); ?>">Home</a>
        <a href="/album">Album</a>
        <a href="/unggahfoto">Unggah Foto</a>
        <a href="/view">Lihat Foto</a>
    </nav>

    <div class="container">
        <h1>Galeri Foto</h1>
        <div class="gallery">
        <?php $__currentLoopData = $foto; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ft): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="image-item">
                <img src="<?php echo e(Storage::url($ft->LokasiFile)); ?>" alt=".........">
                <div class="image-overlay">
                    <h3>Judul Foto : <?php echo e($ft->JudulFoto); ?></h3>
                    <p>Deskripsi Foto : <?php echo e($ft->DeskripsiFoto); ?></p>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>

</body>
</html>
<?php /**PATH C:\Users\asus\website_galeri_foto\resources\views/lihatfotoalbum.blade.php ENDPATH**/ ?>
<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\User;
use App\Models\Album;
use App\Models\Likefoto;
use App\Models\Komentarfoto;
// use App\Models\Album;
use App\Models\Foto;
use Carbon\Carbon;

class Galphotocontroller extends Controller
{
    //
    public function LoginAksi(Request $req){
        $data = User::where('Username', $req->input('username'))->where('password', $req->input('password'))->first();
        if ($data == null) {
            return redirect('/login')->with('pesan', 'Username/Password Salah!');
        } else {
            session()->put('user', $data);
            return redirect('/home');
        }
    }
    public function registrasiaksi(request $req){

    $data = new User;
    $data->Username = $req->input('username');
    $data->Password = $req->input('password');
    $data->email = $req->input('email');
    $data->NamaLengkap = $req->input('fullname');
    $data->Alamat = $req->input('address');

    $data->save();
    return redirect('/login')->with('succes','Registrasi berhasil, silahkan login');

    }
    public function buatalbum(Request $req){
        $data = new Album;
        $data->NamaAlbum = $req->input('judul');
        $data->Deskripsi= $req->input('deskripsi');
        $data->TanggalDibuat= Carbon::now();
        $data->UserID = session('user')->UserID;
        $data->save();
        return redirect('/lihatalbum');

    }
    public function lihatalbum(){
        $data = Album::where('UserID', session('user')->UserID)->get();

        return view('/lihatalbum', compact('data'));
    }
    public function unggahfoto(){
        $data = Album::where('UserID', session('user')->UserID)->get();

        
        return view('/unggahfoto', compact('data'));

    }   
    public function uploadfoto(Request $req){
        $locate = $req->file('image')->store('public/images');

        $data = new Foto;
        $data->JudulFoto = $req->input('title');
        $data->DeskripsiFoto = $req->input('description');
        $data->TanggalUnggah = Carbon::now();
        $data->LokasiFile = $locate;
        $data->AlbumID = $req->input('album');
        $data->UserID = session('user')->UserID;

        // dd($data);
        $data->save();

        return redirect('lihatalbum');
    }
    public function lihatfoto($AlbumID){
        $foto = Foto::where('AlbumID', $AlbumID)->get();
        return view('lihatfotoalbum',compact('foto'));
    }
    public function lihatfoto2($FotoID){

        if(session('user')){
        $foto = Foto::find($FotoID);
        $like = Likefoto::all();
        $user = User::find($foto->UserID);
        $komen = Komentarfoto::where('FotoID', $FotoID)->get();
        $user2 = User::all(); 

        return view('lihatfoto', compact('foto','like','user2','user','komen'));

        }else{
            return redirect()->back()->with('err', 'Kamu harus masuk untuk melihat foto!');
        }
    }

   public function like($FotoID){
        $cek = Likefoto::where('UserID', session('user')->UserID)->where('FotoID', $FotoID)->first();
        if(!$cek){
            $like = new Likefoto;
            $like->FotoID = $FotoID;
            $like->UserID = session('user')->UserID;
            $like->TanggalLike = Carbon::now();
            $like->save();
            
            return redirect()->back();
        }else{

            $cek->delete();
            // dd($cek);

            return redirect()->back();
        }
    }
    public function komen($FotoID, Request $req){
        $komen = new Komentarfoto;
        $komen->FotoID = $FotoID;
        $komen->UserID = session('user')->UserID;
        $komen->IsiKomentar = $req->input('isi');
        $komen->TanggalKomentar = Carbon::now();
        $komen->save();

        return redirect()->back();
    }


}
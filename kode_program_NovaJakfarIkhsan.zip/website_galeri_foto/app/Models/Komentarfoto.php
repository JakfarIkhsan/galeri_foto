<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Komentarfoto extends Model
{
    use HasFactory;
    protected $table='komentarfoto';
    public $timestamps=false;
    protected $guarded=[];
    protected $primaryKey='KomentarID';
}

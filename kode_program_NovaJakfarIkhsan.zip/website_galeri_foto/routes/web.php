<?php

use Illuminate\Support\Facades\Route;
use App\http\Controllers\GalphotoController;
use App\Models\Foto;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/album', function () {
    return view('album');
});
Route::get('/login', function () {
    return view('login');
});
Route::get('/register', function () {
    return view('registrasi');
});
Route::get('/home', function () {
    $foto = Foto::all();
    return view('home', compact('foto'));
});
Route::get('/buatalbum', function () {
    return view('buatalbum');
});

Route::post('/LoginAksi', [Galphotocontroller::class, 'LoginAksi']);
Route::post('/registerasiAksi', [GalphotoController::class, 'registrasiAksi']);
Route::post('/buatalbum', [GalphotoController::class, 'buatalbum']);
Route::get('/lihatalbum', [GalphotoController::class, 'lihatalbum']);
Route::get('/unggahfoto', [GalphotoController::class, 'unggahfoto']);
Route::post('/upload', [GalphotoController::class, 'uploadfoto']);
Route::get('/lihatfoto/{albumID}', [GalphotoController::class, 'lihatfoto']);
Route::get('/lihatfoto2/{FotoID}', [GalphotoController::class, 'lihatfoto2']);
Route::get('/berilike/{FotoID}', [GalphotoController::class, 'like']);
Route::post('/berikomen/{FotoID}', [GalphotoController::class, 'komen']);